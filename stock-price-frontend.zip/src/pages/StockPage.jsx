import React, { useEffect, useState } from 'react';
import StockChart from '../components/StockChart';
import { fetchStocks } from '../api/stockService';
import { Container, Typography } from '@mui/material';

function StockPage() {
  const [stocks, setStocks] = useState([]);
  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    fetchStocks().then(setStocks);
    // Mock data for chart
    setChartData([
      { time: '10:00', price: 120, average: 118 },
      { time: '10:05', price: 122, average: 119 },
      { time: '10:10', price: 121, average: 119.5 },
    ]);
  }, []);

  return (
    <Container>
      <Typography variant="h4">Stock Page</Typography>
      <StockChart data={chartData} />
    </Container>
  );
}

export default StockPage;
