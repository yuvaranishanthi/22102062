import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Paper, Typography } from '@mui/material';

function StockChart({ data }) {
  return (
    <Paper style={{ padding: 20 }}>
      <Typography variant="h6">Stock Price Over Time</Typography>
      <LineChart width={800} height={400} data={data}>
        <CartesianGrid stroke="#ccc" />
        <XAxis dataKey="time" />
        <YAxis />
        <Tooltip />
        <Line type="monotone" dataKey="price" stroke="#8884d8" />
        <Line type="monotone" dataKey="average" stroke="#82ca9d" />
      </LineChart>
    </Paper>
  );
}

export default StockChart;
