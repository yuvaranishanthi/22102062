export const calculateCorrelation = (x, y) => {
  const n = x.length;
  const avgX = x.reduce((a, b) => a + b) / n;
  const avgY = y.reduce((a, b) => a + b) / n;

  const numerator = x.map((xi, i) => (xi - avgX) * (y[i] - avgY)).reduce((a, b) => a + b);
  const denominator = Math.sqrt(
    x.map(xi => (xi - avgX) ** 2).reduce((a, b) => a + b) *
    y.map(yi => (yi - avgY) ** 2).reduce((a, b) => a + b)
  );

  return numerator / denominator;
};
