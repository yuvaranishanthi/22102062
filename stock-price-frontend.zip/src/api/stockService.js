import axios from 'axios';

const BASE_URL = 'http://20.244.56.144/evaluation-service';

export const fetchStocks = async () => {
  const res = await axios.get(`${BASE_URL}/stocks`);
  return res.data.stocks;
};
